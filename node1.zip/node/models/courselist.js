const courselist=
     [
      {
        "course" :"React"
      },
      {
        "course":"Mongo db"
      },
      {
        "course":"Javascript"
      },
      {
        "course":"Java"
      },
      
    ]
    module.exports={courselist};