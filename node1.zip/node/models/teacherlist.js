const teacherlist=
     [
      {
        "id": 1,
        "email": "michael.lawson@reqres.in",
        "name": "Michael"
      },
      {
        "id": 2,
        "email": "lindsay.ferguson@reqres.in",
        "name": "Lindsay"
      },
      {
        "id": 3,
        "email": "tobias.funke@reqres.in",
        "name": "Tobias"
      },
      {
        "id": 4,
        "email": "byron.fields@reqres.in",
        "name": "Byron"
      },
    ]
    module.exports={teacherlist};