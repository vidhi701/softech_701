const databasefile=require('../database/db')


const getdata=async(req,res)=>{
    try{ 
    const db=await databasefile.main();
    const collection = await db.collection('student');
    const findResult =await collection.find({}).toArray();
    console.log('Found Document =>',findResult)
    if(findResult.findcount>0)
    {
    res.send(200).json({
        "status":200,
        "message":findResult
    });
}
else{
    res.status(400).json({
        "status":400,
        "message":"something went wrong"

    })
}
}
    catch(error)
    {

    }
}


const insertdata=async(req,res)=>{
    const db=await databasefile.main();
    const collection = await db.collection('student');
    const insertResult = await collection.insertOne(req.body);
    console.log('Inserted documents =>',insertResult);

res.send({
    status:200,
    "message":insertResult,
})
}


const updatedata=async(req,res)=>{
    console.log("Old name is =>"+req.query.name);
    const db=await databasefile.main();
    const collection = await db.collection('student');
    const updateResult = await collection.updateOne({ Name: req.query.name },{ $set: req.body });
    console.log("Updated document =>",updateResult);
    res.send({
        status:200,
        "message":'record is updated'
    })
}


const deletedata=async(req,res)=>{
    console.log("deleted record=>"+req.query.name)
    const db=await databasefile.main();
    const collection = await db.collection('student');
    const deleteResult = await collection.deleteOne({ Name: req.query.name},{$set:req.body});
    console.log("Updated document =>",deleteResult);
    res.send({
       status:200,
       "message":'record is deleted'
   })

}

   


module.exports={getdata,insertdata,updatedata,deletedata}