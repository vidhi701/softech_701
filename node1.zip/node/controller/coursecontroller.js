const x=require('../models/courselist')

const course=(req,res)=>{
    res.send(
        {
            "status":200,
            "message":x
        }
    )
}
module.exports={course}