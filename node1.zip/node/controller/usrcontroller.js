const databasefile=require('../database/db')


const getuserdata=async(req,res)=>{
    const db=await databasefile.main();
    const collection = await db.collection('user_table');
    //const {User_name}=req.body;
    const findResult =await collection.find({}).toArray();
    console.log('Found Document =>',findResult)
   
    res.send({
        "status":200,
        "message":findResult
    })

}


const insertuserdata=async(req,res)=>{
    const db=await databasefile.main();
    const collection = await db.collection('user_table');
    //const insertResult = await collection.insertOne(req.body);\
   // const {User_name}=req.body;

    const findResult =await collection.findOne({User_name: req.body.User_name});  //(here the username should be on both side same as in the tabledata in mongodb)
    console.log('Checked documents =>',findResult);
   
    if(findResult.Password==req.body.Password)
    {
res.send({
    status:200,
    message:"record exist"
})
    }
    else{
        res.send({
            status:400,
            message:"record doesn't exist"
        }) 
    }
}

module.exports={getuserdata,insertuserdata}