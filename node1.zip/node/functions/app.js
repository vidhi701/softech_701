//app.js

const express = require("express");
const serverless = require("serverless-http");
const app = express();
const indexRouter=require('../router/index')

 
const cors=require('cors')
app.use(cors());

// app.use('/',indexRouter)
app.use(express.json());
app.use("/.netlify/functions/app", indexRouter);
module.exports.handler = serverless(app);
