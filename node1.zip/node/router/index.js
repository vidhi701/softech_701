const express=require('express');
const router=express.Router();
const cStudent=require('../controller/studentcontroller');
const scontrol=require('../controller/stdntcontrol')



router.get('/getrequest',scontrol.getdata)
router.post('/postdata',scontrol.insertdata)
// router.get('/getstudentdata',async (req,res)=>{
//     const collection= await databasefile.main();
//     //const collection = db.collection('db1');
//     const findResult = await collection.find({}).toArray();
//     console.log('Found documents =>', findResult);
//         res.send({
//            "status":200,
//            "message":findResult
//         })
//        })
router.get('*',cStudent.student)
module.exports=router