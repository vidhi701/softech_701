const databasefile=require('../database/db')
const getdata=async(req,res)=>{

    const db=await databasefile.main();
    const collection = await db.collection('student');
    const findResult =await collection.find({}).toArray();
    console.log('Found Document =>',findResult)
    res.send({
        "message":findResult,
        "status":200
    })
}

// const insertdata=async(req,res)=>{
//     const db=await databasefile.main();
//     const collection = await db.collection('student');
//     console.log("coming")
//     const insertResult = await collection.insertOne(req.body);
//     console.log('Inserted documents =>',insertResult);

// res.send({
//     status:200,
//     "message":insertResult,
// })
// }
// const insertdata=async(req,res)=>{
//     const db=await databasefile.main();
//     const collection = await db.collection('user_table');
//     console.log("hello");
//     const findData =await collection.findOne({User_name: req.body.User_name}); 
//     console.log('Checked documents =>',findData);

//     if(findData.Password==req.body.Password)
//         {
//     res.send({
//         status:200,
//         message:"record exist"
//     })
//         }
//         else{
//             res.send({
//                 status:400,
//                 message:"record doesn't exist"
//             }) 
//         }
// }
const insertdata = async (req, res) => {
    try {
        const db = await databasefile.main();
        const collection = await db.collection('user_table');
        console.log("Connected to the database");

        // Find user by 'User_name', not by 'Password'
        const findData = await collection.findOne({ User_name: req.body.User_name });
        console.log('Checked for user =>', findData);

    
        // If user is found, check the password
        if (findData.Password == req.body.Password) {
            console.log("error1");
            console.log("User authenticated successfully");
            res.status(200).send({
                status: 200,
                message: "Record exists"
            });
        } else {
            console.log("Incorrect password");
            res.status(400).send({
                status: 400,
                message: "Incorrect password"
            });
        }
    } catch (error) {
        console.error("Error occurred:", error);
        res.status(500).send({
            status: 500,
            message: "An error occurred while processing your request"
        });
    }
};




module.exports={getdata,insertdata}