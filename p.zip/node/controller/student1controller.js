const x=require('../models/studentlist')

const student=(req,res)=>{
    res.send(
        {
            "status":200,
            "message":x.studentlist
        }
    )
}
module.exports={student}