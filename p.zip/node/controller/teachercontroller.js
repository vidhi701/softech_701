const x=require('../models/teacherlist')

const teacher=(req,res)=>{
    res.send(
        {
            "status":200,
            "message":x.teacherlist
        }
    )
}
module.exports={teacher}