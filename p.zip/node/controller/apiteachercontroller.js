const databasefile=require('../database/db')


const getteacherdata=async(req,res)=>{
    const db=await databasefile.main();
    const collection = await db.collection('teacher');
    const findResult =await collection.find({}).toArray();
    console.log('Found Document =>',findResult)
    res.send({
        "status":200,
        "message":findResult
    })
}


const insertteacherdata=async(req,res)=>{
    const db=await databasefile.main();
    const collection = await db.collection('teacher');
    const insertResult = await collection.insertOne(req.body);
    console.log('Inserted documents =>',insertResult);

res.send({
    status:200,
    message:insertResult
})
}


const updateteacherdata=async(req,res)=>{
    console.log("Old name is =>"+req.query.name);
    const db=await databasefile.main();
    const collection = await db.collection('teacher');
    const updateResult = await collection.updateOne({ Name: req.query.name },{ $set: req.body });
    console.log("Updated document =>",updateResult);
    res.send({
        status:200,
        message:'record is updated'
    })
}


const deleteteacherdata=async(req,res)=>{
    console.log("deleted record=>"+req.query.name)
    const db=await databasefile.main();
    const collection = await db.collection('teacher');
    const deleteResult = await collection.deleteOne({ Name: req.query.name},{$set:req.body});
    console.log("Updated document =>",deleteResult);
    res.send({
       status:200,
       message:'record is deleted'
   })

}

   



module.exports={getteacherdata,insertteacherdata,updateteacherdata,deleteteacherdata}