const student= (req,res)=>{
   
    res.send({
       "status":200,
       "message":"api not found,please correct the url"
       
    })

   }

module.exports={student}